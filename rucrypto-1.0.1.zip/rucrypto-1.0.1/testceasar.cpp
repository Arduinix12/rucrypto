#include<iostream>
#include"Caesar.h"

using namespace std;
Caeser caeser;

string texts="hello world";
int key=3;

/*
int main() {

	caeser.getword(texts);
	caeser.getkey(key);
	cout << "text:" << texts << "\n";
	texts = caeser.encript(texts, key);
	cout<<"encript:"<< texts<<"\n";
	texts = caeser.decript(texts, key);
	cout << "decript:" <<texts << "\n";
}*/