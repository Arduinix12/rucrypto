#include "RSA.h"
#include<iostream>
using namespace std;
/*
int main()
{
	
	
	RSA rsa;

	int p, q;
	cout << "Enter a Prime number p:" << "\n";
	cin >> p;

	cout << "Enter a Prime number q:" << "\n";
	cin >> q;

	rsa.genereytkey(p, q);

	string message;
	cout << "Enter message to be encrypted:" << "\n";
	cin.ignore();
	getline(cin, message);

	string encryptedMessage = rsa.encrypt(message);
	cout << "The encrypted message is: " << encryptedMessage << "\n";

	string decryptedMessage = rsa.decrypt(encryptedMessage);
	cout << "The decrypted message is: " << decryptedMessage << "\n";

	return 0;


}*/
