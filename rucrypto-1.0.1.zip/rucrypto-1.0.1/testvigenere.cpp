#include<iostream>
#include"Vigenere.h"


using namespace std;
string text = "helloworld!";
string key = "text";
VigenereCipher cripto;
//int main() {
	//cripto.setkey(key);
	//string criptotext=cripto.encrypt(text);
	//cout << criptotext;
//}